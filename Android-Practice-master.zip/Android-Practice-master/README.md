# Android-Practice
Android course with teaching Retrofit and constructing a whole project in IIR lab orientation camp
